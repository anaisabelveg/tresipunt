<script setup>
     function mostrar(){
        alert("Has pulsado el boton");
      }
      function derecho(){
        alert("Has pulsado el boton con el boton derecho");
      }
      function dentro(nombre, event){
        alert(nombre + ", Estas dentro del span " + event);
      }
      function fuera(event){
        alert("Estas fuera del span" + event);
      }
</script>

<!--
<script>
  export default{
    methods: {
      mostrar(){
        alert("Has pulsado el boton");
      },
      derecho(){
        alert("Has pulsado el boton con el boton derecho");
      },
      dentro(nombre){
        alert(nombre + ", Estas dentro del span");
      },
      fuera(){
        alert("Estas fuera del span");
      }
    }
  }
</script>
-->


<template>
  <div>
    <button @click.left="mostrar"   @click.right="derecho">Pulsame</button>
    <span @mouseover="dentro('Anabel', $event)" @mouseout="fuera"></span>
  </div>
</template>

<style scoped>
  span{
    display: block;
    background-color: bisque;
    width: 50%;
    height: 50px;
  }
</style>
