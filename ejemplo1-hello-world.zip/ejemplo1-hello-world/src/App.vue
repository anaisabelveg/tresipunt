<template>
    <div>
      <Saludar />
    </div>
</template>

<script setup>
  // importar los componentes a mostrar
  import Saludar from './components/Saludar.vue'
</script>


<style scoped>



</style>
