<script setup>
    import FormularioAlta from './FormularioAlta.vue'
    import {ref} from 'vue'
   
    let productos = ref([
              {id: 1, descripcion: 'Zapatillas Asics', precio: 129.50},
              {id: 2, descripcion: 'Zapatillas Nike', precio: 109.96},
              {id: 3, descripcion: 'Zapatillas Adidas', precio: 188.28},
              {id: 4, descripcion: 'Zapatillas Puma', precio: 92.90},
              {id: 5, descripcion: 'Zapatillas Under Armour', precio: 140.50},
              {id: 6, descripcion: 'Zapatillas Converse', precio: 78.95},
            ]);
        
     function addProducto(nuevo){
            productos.value.push({...nuevo})
     }       
</script>

<template>
  <div>
      <h1>Gestion de productos</h1>
      <table>
        <tr>
          <th>ID</th>
          <th>Descripcion</th>
          <th>Precio</th>
        </tr>

        <template v-for="prod in productos" :key="prod.id">
          <tr v-if="prod.precio > 100" >
            <td> {{ prod.id }} </td>
            <td> {{ prod.descripcion }}</td>
            <td> {{ prod.precio }}</td>
          </tr>
        </template>

        <!--
        <tr v-for="prod in productos" :key="prod.id">
          <td> {{ prod.id }} </td>
          <td> {{ prod.descripcion }}</td>
          <td> {{ prod.precio }}</td>
        </tr>
        -->
      </table>

      <FormularioAlta @enviar-producto="addProducto" />
  </div>
</template>

<style scoped>
h1 {
  font-weight: 500;
  font-size: 2.6rem;
  top: -10px;
}

table, th, td{
  border: thin solid black;
  border-collapse: collapse;
}
</style>
