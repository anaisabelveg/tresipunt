<script setup>  
    let producto={
        id: 0,
        descripcion: '',
        precio: 0
    }
      
    const emit = defineEmits(['enviar-producto']);

    function enviar(){
        emit('enviar-producto', producto)
        
    } 
</script>


<template>
    <div>
        <h2>Alta de productos</h2>
        <form  @submit.prevent="enviar">
            <label>ID:</label>
            <input type="text" v-model="producto.id"  /> <br/>

            <label>Descripcion:</label>
            <input type="text" v-model="producto.descripcion"  /> <br/>

            <label>Precio:</label>
            <input type="text" v-model="producto.precio"  /> <br/>

            <input type="submit" value="Enviar" />
        </form>
    </div>
</template>


<style>

</style>