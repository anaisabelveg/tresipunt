<script setup>
  import CatalogoProductos from './components/CatalogoProductos.vue'
</script>

<template>  
    <div>
      <CatalogoProductos />
    </div>
</template>

<style scoped>

</style>
