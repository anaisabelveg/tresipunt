function longitud(texto){
    return texto.length;
}

export function mayusculas(texto){
    return texto.toUpperCase();
}

export function minusculas(texto){
    return texto.toLowerCase();
}

function buscar(texto, caracter){
    return texto.indexOf(caracter);
}
